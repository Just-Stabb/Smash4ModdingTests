Supamario Kamehameha test 26: copy over test 25 (data/fighter/supamario/...).
Only supamario.mscsb and the body sound.bin change: the Kamehameha's sounds play from the MSC,
so landing during the move no longer replays them.
